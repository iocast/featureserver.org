__author__  = "MetaCarta"
__copyright__ = "Copyright (c) 2006-2008 MetaCarta"
__license__ = "Clear BSD" 
__version__ = "$Id: __init__.py 412 2008-01-01 08:15:59Z crschmidt $"
