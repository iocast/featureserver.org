'''
Created on Apr 5, 2011

@author: michel
'''

from FeatureServer.WebFeatureService.FilterEncoding.LogicalOperators.LogicalOperator import LogicalOperator

class And(LogicalOperator):
    ''' '''