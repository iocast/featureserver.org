'''
Created on Apr 5, 2011

@author: michel
'''
from FeatureServer.WebFeatureService.FilterEncoding.ComparisonOperators.ComparisonOperator import ComparisonOperator

class PropertyIsEqualTo(ComparisonOperator):
    ''' '''
    