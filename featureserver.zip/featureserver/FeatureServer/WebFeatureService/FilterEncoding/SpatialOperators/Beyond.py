'''
Created on May 9, 2011

@author: michel
'''

from FeatureServer.WebFeatureService.FilterEncoding.SpatialOperators.SpatialOperator import SpatialOperator

class Beyond(SpatialOperator):
    ''' '''
            