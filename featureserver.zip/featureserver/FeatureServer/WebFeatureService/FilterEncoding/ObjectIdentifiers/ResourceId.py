'''
Created on Apr 5, 2011

@author: michel
'''

from FeatureServer.WebFeatureService.FilterEncoding.ObjectIdentifiers.ObjectIdentifier import ObjectIdentifier

class ResourceId(ObjectIdentifier):
    ''' '''